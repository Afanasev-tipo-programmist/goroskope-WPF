﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace Horoscope1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Log("Приложение запущено.");
        }
        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string password = PassBox.Password; // Получаем пароль (обратите внимание на Password)

            // Ваша логика проверки пароля (например, сверка с базой данных)
            if (password == "Userloser") // Замените на реальную проверку
            {
                Log("Успешный вход!");
                //Включение элементов при правильном пароле
                ChooseZZlbl.Visibility = Visibility.Visible;
                ZodiacComboBox.Visibility = Visibility.Visible;
                PredictionBtn.Visibility = Visibility.Visible;
                PredictionTextBlock.Visibility = Visibility.Visible;
                //выключение меню пароля при правильном пароле
                passLbl.Visibility = Visibility.Hidden;
                passBtn.Visibility = Visibility.Hidden;
                PassBox.Visibility = Visibility.Hidden;
            }
            else
            {
                Log("Неверный пароль.");
            }

            // Очищаем PasswordBox после использования
            PassBox.Clear();
        }
        private void Log(string message)
        {
            string logMessage = $"{DateTime.Now}: {message}\n";

            // 1. Вывод в TextBox (для отображения в UI)
            LogTextBox.AppendText(logMessage);
            LogTextBox.ScrollToEnd(); // Автоматическая прокрутка к последней записи

        }
        private List<string> Prediction = new List<string>()
        {
          "Этот день может оживить чувства Овнов и их тягу к прекрасному, усилить их потребность в комфорте, любви, красоте или гармонии, в лакомствах или приятных обновках. Исполнение ряда желаний требует денег, поэтому звезды советуют обратить внимание на материальную часть (например, изучить новости в финансовой сфере и уточнить свой бюджет) Также не помешает подумать о своих привычках в питании.",
          "Тельцам этот день сулит новости и перемены в настроении. Возможно, станут живее и непосредственнее реакции, потянет на яркие краски, смелые шаги или тайные нестандартные капризы. Новый настрой поможет уходить от психологического давления в общении и находить позитив даже в неприятной информации. Может состояться разговор, обновиться система связи, составленный текст или используемая программа.",
           "Этот день несет Близнецам преимущественно добрые знаки. Он подтвердит факт окончания затяжной паузы в их делах, может приоткрыть им новые перспективы в любви, дружбе или творчестве. Наибольшие сложности могут быть связаны с материальной базой. Возможны неожиданные вести издалека или сообщения от друзей, меняющие текущие планы. Лучше повременить с отправкой в путь и важными финансовыми операциями.",
           "Сегодня звезды советуют Ракам отложить рутину и заняться обновлениями. День подходит и для обсуждения новинок, и для их внедрения в практику. Он хорош для перехода на новые версии программ, для обсуждения перспектив будущего с друзьями или с теми, с кем вы временно в одной лодке. Новшества этого дня могут повлиять на ряд сфер жизни, включая финансы, жилье, отношения с начальством и партнерами.",
           "Львам важно серьезнее отнестись к сегодняшним встречам, совещаниям и предложениям. Несмотря на неформальный оттенок, они имеют вполне конкретное влияние на дальнейшее развитие отношений с нужными людьми и на процесс достижения поставленной общей цели. Стоит приготовиться к доле психологического давления, которое может исходить от собеседников, включая партнеров, друзей, родню и начальство.",
           "Сегодня события разворачиваются не вполне стандартно и предсказуемо, но для Дев это оборачивается чем-то хорошим. Возрастает вероятность получить полезную информацию из чужих краев или из неожиданных источников, которая поможет принять верное решение в финансовой или иной сложной ситуации. Найдутся свои приятные стороны в обновлении программ и расписаний, сбросе паролей, изменении условий сделки.",
           "Сегодня для Весов возрастает важность взаимодействия с другими людьми, с которыми их связало партнерство, конкуренция или спор интересов. День указывает на материальную часть ситуации, так как она способна сыграть роль и в поддержке сотрудничества, и в улаживании противоречий. Внимания может требовать совместное имущество или бюджет нестандартного проекта, а для супругов - обеспечение нужд детей.",
           "Сегодня звезды советуют Скорпионам быть внимательнее в переговорах, включая семейные беседы и дискуссии в домовых чатах. Велика вероятность недовольства там, где раньше царило согласие (особенно, когда дело касается жилья, территории или правил общежития, а также виртуальных площадок, интернета). День хорош для обсуждения новостей и перемен, но лучше воздержаться от новых официальных соглашений.",
           "Сегодня Стрельцы получат хороший знак, если устали от заминок в общении с нужными им людьми. Возможны новости в связи с работой, с обновлениями программ и средств связи, а также приятные подвижки в личной жизни, игре или сфере творчества. С наиболее важными для себя диалогами и встречами звезды советуют повременить: этот день может направить внимание на детали, уводящие в сторону от главной темы.",
           "Сегодня звезды советуют Козерогам отслеживать финансовые новости, свежие отзывы о покупках и информацию о новинках - в том числе, касающихся компьютерных программ и средств связи. Возможно, удастся узнать что-то через друзей. Полученные сведения могут немного шокировать, но также дать ценные подсказки, натолкнуть на интересные идеи или на пересмотр планов (например, на изменения в списке трат).",
           "Этот день может направить внимание Водолеев на практическую часть их жизни (жилье, питание, хозяйство, финансовую базу), намекая, что здесь нужны обновления. Но он также намекнет, что им вновь открыты зарезервированные широкие возможности в других сферах, способствующие их личностному росту и успешной самореализации. Может неожиданно состояться важный разговор с домочадцами или близкими друзьями.",
           "Ситуации этого дня несут в себе для Рыб положительный потенциал, но требуют доли осторожности - особенно, когда речь идет о нужных для дел программах и средствах связи, о деньгах или покупках. Стоит дать себе немного времени на обдумывание любой входящей информации: лишь в этом случае решение будет верным. Возможны неожиданные новости, сюрпризы в поездках и в процессе финансовых операций.",

        };

        List<string> images = new List<string>()
        {
           "https://img.icons8.com/external-others-maxicons/62/external-aries-celestial-and-witchcraft-others-maxicons.png",
           "https://img.icons8.com/external-others-maxicons/62/external-taurus-celestial-and-witchcraft-others-maxicons.png",
           "https://img.icons8.com/external-others-maxicons/62/external-gemini-celestial-and-witchcraft-others-maxicons.png",
           "https://img.icons8.com/external-others-maxicons/62/external-cancer-celestial-and-witchcraft-others-maxicons.png",
           "https://img.icons8.com/external-others-maxicons/62/external-leo-celestial-and-witchcraft-others-maxicons.png",
           "https://img.icons8.com/external-others-maxicons/62/external-virgo-celestial-and-witchcraft-others-maxicons.png",
           "https://img.icons8.com/external-others-maxicons/62/external-libra-celestial-and-witchcraft-others-maxicons.png",
           "https://img.icons8.com/external-others-maxicons/62/external-scorpio-celestial-and-witchcraft-others-maxicons.png",
           "https://img.icons8.com/external-others-maxicons/62/external-sagitarius-celestial-and-witchcraft-others-maxicons.png",
           "https://img.icons8.com/external-others-maxicons/62/external-capricorn-celestial-and-witchcraft-others-maxicons.png",
           "https://img.icons8.com/external-others-maxicons/62/external-aquarius-celestial-and-witchcraft-others-maxicons.png",
           "https://img.icons8.com/external-others-maxicons/62/external-pisces-celestial-and-witchcraft-others-maxicons.png"


        };

        


        private void GetPrediction_Click(object sender, RoutedEventArgs e)
        {
            int index = ZodiacComboBox.SelectedIndex;
            PredictionTextBlock.Text = Prediction[index];
            ZodiacImage.Source = new BitmapImage(new Uri(images[index], UriKind.Absolute));
        }

        private void ZodiacComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
        }
    }
}